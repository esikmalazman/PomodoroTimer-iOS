# pomdoro-timer-iOSApp

a simple pomodoro timer develop with swift programming language

# What I learn from this project

1. create multiscreen app using segues
2. design user interface with auto layout and constraint
3. develop user interface programatically
4. utilize AVFoundation module to play sound
5. pass user input from one screen to another screen app


# Version 1.1
1. Bug Fix (App allow user to continue to another screen without a task)
2. Refactor Code & update UI
3. Fix background layout for iPad


# Future Updates

1. Roundings

